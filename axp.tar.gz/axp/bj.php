<?php
include 'session_check.php';
exec("/usr/bin/sudo /bin/sh  /var/www/html/tools/bj.sh");
echo "<script>alert('配置【非东莞本地】爱学派服务器成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
?>

