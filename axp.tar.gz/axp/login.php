<!DOCTYPE html>
<center>
<meta charset="utf-8">
<title>爱学派服务器管理V2.2</title>
<link rel="icon" href="http://www.etiantian.com/favicon.ico" />
<center><font color='blue'><?php
include '/var/www/html/get_ipinfo.php';
echo " 主机名: ".gethostname()."<br/>";
echo "id：$u_uuid<br/>";
?></font></center>
<link rel="stylesheet" type="text/css" href="style.css" />
<body>
<div class="container">
<section id="content">
<form action="check_user_pwd.php" method="post">
<h1>管理员登录</h1>
<input type="text" name="username" placeholder="用户名"/>
<input type="password" name="password" placeholder="密码" />
<input type="submit" value="登录" />
</form>
<form action="forgot_pwd.php" methgd="post" target="_blank">
<input type="submit" value="忘记密码？" />
</form>
</div>
<div class="container">
<section id="content">
<form action="http://10.20.30.254/ok.php" method="post" name="status" target="_blank">
<center><input type="submit" value="查看服务器状态"></center>
</form>
<form action="http://school.etiantian.com/tcfileupload/helpdoc/school/teacher/help.zip" method="post" name="down_ax_file" target="_blank">
<center><input type="submit" value="爱学使用手册"></center>
</form>
<form action="http://10.20.30.254:888/AXP_V3.1.docx" method="post" name="down_axp_file" target="_blank">
<center><input type="submit" value="爱学派使用手册"></center>
</form>
<form action="https://web.etiantian.com/ett20/app/aixue-pad.jsp" method="post" name="down_axp" target="_blank">
<center><input type="submit" value="下载爱学派App"></center>
</form>
<form action="http://web.etiantian.com/ett20/app/aixue-android.jsp" method="post" name="down_aixue" target="_blank">
<center><input type="submit" value="下载爱学App"></center>
</form>
<form action="https://10.20.30.10" method="post" name="ap" target="_blank">
<center><input type="submit" value="调试无线AP"></center>
</form>
</div>
</body>
<link rel="icon" href="favicon.ico" />
</html>
