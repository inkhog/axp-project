<?php
header("Content-type: text/html; charset=utf-8");
echo "更新大概需要5分钟，请耐心等待。。。";
exec("/usr/bin/sudo  sh /var/www/html/tools/update.sh");
echo "<script>alert('更新成功！');location.href='statu.php';</script>";
?>
