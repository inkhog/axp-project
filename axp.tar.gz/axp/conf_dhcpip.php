<form action="dhcp_ip.php" method="post">
<center>点击下方确认按钮后将自动获取ip，点击确认后请勿重复操作，系统获取ip并配置需要一定时间</center><br/><br/>
<center><input type="submit"  value="确认" /></center><br/>
</form>
<?php
header("Content-type: text/html; charset=utf-8"); 
date_default_timezone_set("Asia/Shanghai");
echo "<center>现在时间: ".date('Y-m-d,H:i:s</center>');
include 'session_check.php';
?>

