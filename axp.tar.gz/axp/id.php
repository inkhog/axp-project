<?php
header("Content-type: text/html; charset=utf-8");
exec("/usr/bin/sudo chmod 777 /opt/www/ettschoolmitm/mitm2ettschool/uuid");
$u_uuid=exec("/usr/bin/sudo cat /opt/www/ettschoolmitm/mitm2ettschool/uuid");
if ($u_uuid == ""){
exec("/usr/bin/sudo uuidgen > /opt/www/ettschoolmitm/mitm2ettschool/uuid");
echo "<script>alert('更新服务器id成功！');location.href='id.php';</script>";
echo "id:  ".$u_uuid;
}
else{
echo "id :  ".$u_uuid;
}
?>


