<?php
session_start();
$username='admin';
$password="74ba0da6ac7cba8697146451a634dfb8";
if ($_SESSION['username']!==$username && $_SESSION['password']!==$password){
header("Location: login.php");
}
header("Content-type: text/html; charset=utf-8"); 
?>
<link rel="icon" href="favicon.ico" />


