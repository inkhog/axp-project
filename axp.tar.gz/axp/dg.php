<?php
include 'session_check.php';
$city = exec("/usr/bin/sudo curl myip.ipip.net");
if(ereg("东莞",$city)){
exec("/usr/bin/sudo /bin/sh  /var/www/html/tools/dg.sh");
echo "<script>alert('配置【东莞本地】爱学派服务器成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else
{
echo "<script>alert('您当前地理位置不属于东莞本地，无法更改为【东莞本地配置】！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>

