<?php
include 'session_check.php';
$add_ips = $_POST["add_ips"];
if(ereg("^10\.+20\.+30\.+24+[0-9]$",$add_ips)){
exec("/usr/bin/sudo  echo '$add_ips' >> /etc/squid/allow_ips");
exec("/usr/bin/sudo  squid -krec");
echo "<script>alert('添加信任IP成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
$arr = array(`cat /etc/squid/allow_ips`);
foreach($arr as $value){ 
echo "已添加的信任IP分别为：</br> $value </br>"; 
}
}
else
{
echo "<script>alert('输入的IP地址不合法，请重新输入！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
} 
?>


