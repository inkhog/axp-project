<?php
include 'session_check.php';
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="http://www.etiantian.com/favicon.ico" />
<title>爱学派服务器管理V2.3</title> 
</head>
<frameset cols="25%,75%">
<frame noresize="noresize" src="axp.php">
<frame noresize="noresize" src="statu.php"  name="status" id="status">
</frameset>
</html>

