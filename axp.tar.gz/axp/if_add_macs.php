<form action="is_add_macs.php" method="post">
<center>点击下方按钮确认是否将班级所有pad的mac地址添加到白名单</center><br/><br/>
<center><input type="submit"  value="确认" /></center><br/>
</form>

<form action="del_allow_macs.php" method="post">
<center><input type="submit" value="删除已添加的MAC地址" /></center>
</form>

<?php
include 'session_check.php';
$mac_file='/etc/squid/allow_macs';
$arr = array(`cat $mac_file`); 
$filesize=abs(filesize($mac_file));
if($filesize<1){
echo "目前无添加MAC地址！";
}
else
{
$file_arr = file($mac_file);
echo "目前已加MAC地址分别为：<br /><br />";
for($i=0;$i<count($file_arr);$i++){
echo $file_arr[$i]."<br />";
}
} 
?>


