<?php 
include 'session_check.php';
exec("/usr/bin/sudo /bin/sh  /opt/www/ettschoolmitm/mitm2ettschool/go.sh &");
echo "<script>alert('归档成功！');location.href='statu.php';</script>";
?>
