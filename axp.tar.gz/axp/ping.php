<?php
header("Content-type: text/html; charset=utf-8");
$ett="baidu.com";
$res=exec("ping $ett -c1|grep 'icmp_seq=1'|grep 'ttl='|wc -l");
if ($res==1){
echo "外网,<font color='red'>OK.</font><br/>";
}
else{
echo "外网,<font color='red'>Faild,请检查网线是否插好或网络设置是否正确！！！</font><br/>";
}
?>
