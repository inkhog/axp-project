<?php 
include 'session_check.php';
$time_h = $_POST["gj_h"];
$time_m = $_POST["gj_m"];
$is_exit = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown -h now'|wc -l");
$u_h = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown'|awk -F ' ' '{print $2}'");
$u_m = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown'|awk -F ' ' '{print $1}'");
if ($is_exit==0)
{
echo "<center>目前无设置的自动关机时间!</center>";
exec("/usr/bin/sudo  chmod 777  /etc/crontab");
exec("/usr/bin/sudo  echo '$time_m $time_h  * * * root /sbin/shutdown -h now' >> /etc/crontab");
exec("/usr/bin/sudo  chmod 0600  /etc/crontab");
exec("/usr/bin/sudo  /etc/init.d/crond restart");
echo "<script>alert('设置定时关机成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else
{
echo "<script>alert('已设置关机时间为：$u_h:$u_m,如需重新设置请先删除!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>


