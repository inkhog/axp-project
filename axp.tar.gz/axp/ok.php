<?php
header("Content-type: text/html; charset=utf-8"); 
include '/var/www/html/statu.php';
echo "检测网络连通性:<br/>";
$schoolett =   "school.etiantian.com";
exec("ping -n -c 3 $schoolett", $ping1, $status);
echo "<pre>".htmlentities(print_r($ping1, true))."</pre>";
?>
