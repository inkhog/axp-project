<?php 
include 'session_check.php';
?>

<form action="input_new_pwd.php" method="post" name="edit_pwd" target="status">
<input type="submit" value="修改登录密码" /></br>
</form>

<form action="input_hostname.php" method="post" name="hostname" target="status">
<input type="submit" value="修改服务器主机名">
</form>


<form action="clearcache.php" method="post" name="clearcache" target="status">
<input type="submit" value="清除所有缓存">
</form>

<form action="shutdown.php" method="post" name="reboot" target="status">
<input type="submit" value="关机">
</form>

<form action="reboot.php" method="post" name="reboot" target="status">
<input type="submit" value="重启">
</form>

<form action="input_ip.php" method="post" name="static_ip" target="status">
<input type="submit" value="配置【静态】IP">
</form>

<form action="conf_dhcpip.php" method="post" name="dhcp_ip" target="status">
<input type="submit" value="配置【自动获取】IP">
</form>

<form action="dhcp_static.php" method="post" name="dhcp_to_static" target="status">
<input type="submit" value="将自动获取的IP配置为静态IP">
</form>

<form action="yidong.php" method="post" name="yd_net" target="status">
<input type="submit" value="手动配置DNS">
</form>

<form action="is_auto_dns.php" method="post" name="auto_dns" target="status">
<input type="submit" value="自动获取DNS">
</form>

<form action="time_off.php" method="post" name="off" target="status">
<input type="submit" value="设置定时开关机">
</form>


<form action="upload.php" method="post" name="upload" target="status">
<input type="submit" value="上传文件">
</form>


<form action="guidang.php" method="post" name="guidang" target="status">
<input type="submit" value="手动归档">
</form>

<form action="up.php" method="post" name="up" target="status">
<input type="submit" value="开启行为管理">
</form>

<form action="down.php" method="post" name="down" target="status">
<input type="submit" value="关闭行为管理">
</form>
