#!/bin/bash
LOPMK=2
while [ $LOPMK -gt 1 ]
do
        #dead loop
        XWGLS=`iptables -L -n  | grep 123.103 | wc -l`
        if [ $XWGLS -gt 0 ] ; then
        #if [ $XWGLS -gt -1 ] ; then
               LOOPM=2

                #xingweiguanli nat forward open now
                for DM in cdn1.school.etiantian.net cdn5.hd.etiantian.net
                do
                        for DNSSR in 223.5.5.5 114.114.114.114
                        do
                                #dns server
                                #echo $DNSSR
                                #dig domain ip from dns server
                                for IP in $(dig +short $DM @$DNSSR | grep -v ";" | grep -v "etiantian" | sort)
                                do
                                        #echo $IP
                                        CKIPINFR=`iptables -L -n | grep $IP | wc -l`
                                        if [ $CKIPINFR -lt 1 ] ; then
                                                #echo "nat forward not include this ip $IP"
                                                iptables -I FORWARD -p tcp -s 10.20.30.0/24 -d $IP -j ACCEPT
                                        fi
                                done
                        done
                done
        fi

        #sleep 30s for next loop
        sleep 30
done
