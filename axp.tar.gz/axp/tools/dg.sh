#!/bin/bash
scp -r /var/www/html/tools/dg/* /opt/nginx/conf
cd /opt/www/ettschoolmitm/mitm2ettschool/
scp  go.sh.dongguan go.sh
/etc/init.d/nginx.init restart
/etc/init.d/php-fpm  restart
