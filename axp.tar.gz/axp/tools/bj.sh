#! /bin/bash
scp  /var/www/html/tools/bj/* /opt/nginx/conf
/etc/init.d/nginx.init restart
cd /opt/www/ettschoolmitm/mitm2ettschool/
scp go.sh.bj go.sh
sh go.sh
/etc/init.d/nginx.init restart
/etc/init.d/php-fpm  restart
