#! /bin/bash

iptables -F
iptables -F -t nat
iptables -P INPUT ACCEPT 
iptables -P OUTPUT ACCEPT 
iptables -P FORWARD ACCEPT

iptables -t nat -A POSTROUTING -s 10.20.30.0/24 -o eth1 -j MASQUERADE 


/etc/init.d/iptables save
/etc/init.d/iptables restart
/etc/init.d/squid start
squid -krec

iptables -nvL
iptables -t nat -L

