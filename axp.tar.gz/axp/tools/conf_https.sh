#!/bin/bash
cd /var/www/html/axp/tools/https/
killall -9 nginx
scp *.conf /opt/nginx/conf/
scp nginx /opt/nginx/sbin/
/etc/init.d/nginx.init start

