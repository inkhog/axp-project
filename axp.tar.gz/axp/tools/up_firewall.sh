#! /bin/bash

iptables -F
iptables -F -t nat
iptables -P INPUT ACCEPT 
iptables -P OUTPUT ACCEPT 
iptables -P FORWARD ACCEPT

iptables -A FORWARD -p tcp -s 10.20.30.0/24 -d 	123.103.19.0/24    -j  ACCEPT
iptables -A FORWARD -p tcp -s 10.20.30.0/24 -d 	123.103.75.0/24    -j  ACCEPT
iptables -A FORWARD -p tcp -s 10.20.30.0/24 -d 	10.20.30.0/24      -j  ACCEPT
iptables -A FORWARD -p tcp -s 10.20.30.0/24 -d 	58.218.92.0/24     -j  ACCEPT
iptables -A FORWARD -p tcp -s 10.20.30.0/24 -d 	58.218.198.0/24    -j  ACCEPT
iptables -A FORWARD -p tcp -s 10.20.30.0/24 -d 	218.244.136.0/24   -j  ACCEPT

iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.20.30.0/24  -m multiport --dport  80,808,1080,4000,8000,8080,14000  -j REDIRECT --to-port 3128
iptables -t nat -A PREROUTING -i eth0 -p udp -s 10.20.30.0/24  -m multiport --dport  4000,8000 -j REDIRECT --to-port 3128
iptables -t nat -A POSTROUTING  -s 10.20.30.0/24 -o eth1  -j MASQUERADE 

iptables -A FORWARD -p tcp  -s 10.20.30.0/24 -j DROP

/etc/init.d/iptables save
/etc/init.d/iptables restart
iptables -nvL
iptables -t nat -L
/etc/init.d/squid start
squid -krec
