<?php
header("Content-type: text/html; charset=utf-8");
echo exec("/usr/bin/sudo curl myip.ipip.net");
?>
