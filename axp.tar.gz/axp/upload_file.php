<?php
include 'session_check.php';
$path = "/var/www/html/ett";
if (!file_exists($path)){
exec("/usr/bin/sudo  mkdir -p  $path"); 
exec("/usr/bin/sudo  chown apache:apache  $path"); 
exec("/usr/bin/sudo  chmod 777   $path"); 
}
if (($_FILES["file"]["size"]) < 1 )
{
echo "<script>alert('上传文件不能为空！请选择文件！！！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
elseif (file_exists("ett/" . $_FILES["file"]["name"]))
{
echo $_FILES["file"]["name"] . "已存在！. ";
}
else
{
move_uploaded_file($_FILES["file"]["tmp_name"],
"ett/" . $_FILES["file"]["name"]);
echo "<script>alert('文件上传成功！');</script>";
echo "文件名: " . $_FILES["file"]["name"] . "<br />";
echo "文件类型: " . $_FILES["file"]["type"] . "<br />";
echo "文件大小: " . ($_FILES["file"]["size"] / 1024 / 1024) . " MB<br/>"; 
}
?>
<form action="http://10.20.30.254:888/ett" method="post" name="dir_upload">
<center><input type="submit" value="查看已上传文件"></center>
</form>
<form action="upload.php" method="post" name="upload">
<center><input type="submit" value="继续上传文件"></center>
</form>


