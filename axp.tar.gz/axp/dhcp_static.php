<form action="dhcp_to_static.php" method="post">
<center>点击下方按钮确认是否将自动获取的ip自动配置为静态ip</center><br/><br/>
<center><input type="submit"  value="确认" /></center><br/>
</form>
<?php
include 'session_check.php';
?>

