#!/bin/bash
cd /var/www/html
rm -rf 2017*.zip
now=`date +%Y%m%d%H%M`
zip -r $now.zip ./*
scp $now.zip /tmp
rm -rf $now.zip
ls /tmp/$now.zip

