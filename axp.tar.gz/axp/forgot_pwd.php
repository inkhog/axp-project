<form action="set_def_pwd.php" method="post">
<br/><br/>
<center>请输入验证码,提交后,密码将重置为默认登录密码</center><br/><br/>
<center>请输入验证码： <input type="password" name="user_sn" ></center><br/><br/>
<center><input type="submit"  value="提交" /></center>
</form>
