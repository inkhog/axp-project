<?php
include 'session_check.php';
echo "<center>请输入您需要加入的白名单(域名或者ip):</center><br/>";
echo "<center>添加说明：比如您学校网址为:www.etiantian.com，请输入.etiantian.com,ip地址同理,
多个地址或者ip之间按回车键隔开即可，每行一个地址</center><br/>";
$url_file='/etc/squid/allow_add_urls';
$file_arr = file($url_file);
$url_exit=exec("/usr/bin/sudo sed -n '1,\$p' /etc/squid/allow_add_urls |wc -l");
if ($url_exit!=="0"){
echo "<center>用户添加的白名单地址分别为：</center></br>";
for($j=0;$j<count($file_arr);$j++){
echo $file_arr[$j]."<br />";
}
}
else
{
echo "<center>目前无用户添加白名单地址！</center><br/><br/>";
}
?>
<form action="allow_urls.php" method="post">
<center><textarea  type="text" name="add_urls" id="001" rows="1" onpropertychange="this.style.height=this.scrollHeight+'px';"  oninput="this.style.height=this.scrollHeight+'px';" style="overflow:hidden;height:100px;"></textarea></center></br>
<center><input type="submit" value="提交" /></center>
</form>

<form action="del_allow_urls.php" method="post">
<center><input type="submit" value="删除已添加的白名单" /></center>
</form>
