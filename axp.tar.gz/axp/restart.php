<?php
include 'session_check.php';
exec("/usr/bin/sudo reboot");
echo "<script>alert('【重启】服务器成功！');location.href='statu.php';</script>";
?>

