<?php
include 'session_check.php';
echo "<center>请输入您需要加入的不受限制的IP:</center><br/>";
echo "<center>添加说明：仅允许添加10.20.30.240-250网段,比如您要添加10.20.30.241，输入10.20.30.241即可，多个ip之间按回车键隔开</center><br/>";
$ip_file='/etc/squid/allow_ips';
$arr = array(`cat $ip_file`); 
$filesize=abs(filesize($ip_file));
if($filesize<1){
echo "目前无添加IP地址！";
}
else
{
$file_arr = file($ip_file);
echo "目前已加IP地址分别为：<br /><br />";
for($i=0;$i<count($file_arr);$i++){
echo $file_arr[$i]."<br />";
}
} 
?>
<form action="allow_ips.php" method="post">
<center><textarea  type="text" name="add_ips" id="001" rows="1" onpropertychange="this.style.height=this.scrollHeight+'px';"  oninput="this.style.height=this.scrollHeight+'px';" style="overflow:hidden;height:100px;"></textarea></center></br>
<center><input type="submit" value="提交" /></center>
</form>

<form action="del_allow_ips.php" method="post">
<center><input type="submit" value="删除已添加的ip" /></center>
</form>

