<?php 
include 'session_check.php';
$file_siz=exec("/usr/bin/sudo du /var/www/html/ett/");
if( $file_siz<=4){
echo "<script>alert('目前没有上传文件！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else{
exec("/usr/bin/sudo rm -rf /var/www/html/ett/*");
echo "<script>alert('删除成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>

