<form action="auto_dns.php" method="post">
<center>点击下方按钮确认是否自动获取DNS</center><br/><br/>
<center><input type="submit"  value="确认" /></center><br/>
<center>点击确认按钮之后请等候1分钟，请勿重复提交，系统配置DNS需要一定时间，请耐心等待...</center><br/>
</form>
<?php
include 'session_check.php';
?>

