<?php
include 'session_check.php';
$macs=exec("/usr/bin/sudo sort -k2n /var/log/messages|awk -F 'dhcpd: DHCPDISCOVER from' '{print $2}'|awk '{print $1}'|sed '/^$/d'|awk '{if ($0!=line) print;line=$0}'|wc -l");
if($macs=="1"){
exec("/usr/bin/sudo sort -k2n /var/log/messages|awk -F 'dhcpd: DHCPDISCOVER from' '{print $2}'|awk '{print $1}'|sed '/^$/d'|awk '{if ($0!=line) print;line=$0}' > /etc/squid/allow_macs");
exec("/usr/bin/sudo  squid -krec");
echo "<script>alert('批量添加MAC地址成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else
{
echo "<script>alert('目前没有连接设备的MAC地址！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>
