<?php
include 'session_check.php';
include 'get_ipinfo.php';
$dns1 = $_POST["dns1"];
$dns2 = $_POST["dns2"];
$dns = "/etc/resolv.conf";
$eth1 = "/etc/sysconfig/network-scripts/ifcfg-eth1";
$ipinfo =  array("$dns1");
foreach ($ipinfo as $value) {
}
if ($value !=""){
if (filter_var($value,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)){
exec("/usr/bin/sudo chmod 777 $eth");
exec("/usr/bin/sudo echo DEVICE=eth1'\n'ONBOOT=yes'\n'BOOTPROTO=static'\n'IPADDR=$u_ip'\n'NETMASK=$u_netmask'\n'GATEWAY=$u_gateway'\n'DNS1=$dns1'\n'DNS2=$dns2 > $eth1");
exec("/usr/bin/sudo /etc/init.d/network restart");
exec("/usr/bin/sudo /etc/init.d/NetworkManager restart");
exec("/usr/bin/sudo source /etc/profile");

sleep(10);

include 'get_ipinfo.php';
include 'check_ip.php';
}
}
else {
echo "<script>alert('输入的DNS信息不合法或者DNS信息不完整，请检查确认后重新输入');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>
