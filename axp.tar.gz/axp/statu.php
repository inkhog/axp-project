<!DOCTYPE html>
<html>
<meta charset="utf-8">
<link rel="icon" href="http://www.etiantian.com/favicon.ico" />
<title>爱学派服务器状态</title>
</html>
<?php
header("Content-type: text/html; charset=utf-8");
include '/var/www/html/get_ipinfo.php';
echo "<font color='blue'>";
echo "------------------------------------------------------------------------<br/>";
$ver = "V2.3-20181105";
echo "版本号：",$ver,"<br/>";
echo " 主机名: ".gethostname()."<br/>";
echo "id：$u_uuid<br/>";
echo " 本机IP: ".$_SERVER['REMOTE_ADDR']."<br/>";
echo " 时间: ".date('Y-m-d,H:i:s',$_SERVER['REQUEST_TIME'])."<br/>";
echo "------------------------------------------------------------------------<br/>";
echo "eth0网卡信息：<br/>";
echo "IP  ：$u_ip0<br/>";
echo "MAC地址：$u_mac0<br/>";
echo "子网掩码：$u_netmask0<br/>";
echo "--------------------------------<br/>";
echo "eth1网卡信息：<br/>";
echo "IP  ：$u_ip<br/>";
echo "MAC地址：$u_mac<br/>";
echo "子网掩码：$u_netmask<br/>";
echo "网关：$u_gateway<br/>";
echo "DNS1：$u_dns1<br/>";
echo "DNS2：$u_dns2<br/>";
echo "------------------------------------------------------------------------<br/>";
echo "各服务运行状态：<br/>";
if ($u_ip=="1500"){
echo "<font color='red'>eth1外网网卡未获取到ip，请登录后台点击按钮：配置为自动获取ip或设置为静态ip</font><br/>";
}
include 'ping.php';
//nginx
$ngs80=exec("netstat -ln | grep :80 | wc -l");
if($ngs80=="1")
    echo "nginx, <font color='red'>OK.</font><br/>";
else
    echo "nginx, <font color='red'>Failed.</font><br/>";
//php
$phpst=exec("netstat -ln | grep -w 9000 | wc -l");
if($phpst=="1")
    echo "php, <font color='red'>OK.</font><br/>";
else
    echo "php, <font color='red'>Failed.</font><br/>";
//redis
$redst=exec("netstat -lnp | grep -w :6379 | wc -l");
if($redst=="1")
    echo "redis, <font color='red'>OK.</font><br/>";
else
    echo "redis, <font color='red'>Failed.</font><br/>";
//http
$httpst=exec("netstat -ln | grep -w 888 | wc -l");
if($httpst=="1")
    echo "apache, <font color='red'>OK.</font><br/>";
else
    echo "apache, <font color='red'>Failed.</font><br/>";
//if_up3128
$xwgl=exec("iptables -L -n -t nat | grep 3128| wc -l");
if($xwgl=="0")
    echo "行为管理, <font color='red'>关闭状态.</font><br/>";
else
    echo "行为管理, <font color='red'>开启状态.</font><br/>";
echo "------------------------------------------------------------------------<br/>";
?>
