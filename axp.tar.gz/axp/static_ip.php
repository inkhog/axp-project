<?php
include 'session_check.php';
$ip = $_POST["ip"];
$netmask = $_POST["netmask"];
$gateway = $_POST["gateway"];
$dev = "eth1";
$eth = "/etc/sysconfig/network-scripts/ifcfg-eth1";
$ipinfo =  array("$ip","$netmask","$gateway");
foreach ($ipinfo as $value) {
}
if ($value !=""){
if (filter_var($value,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)){
exec("/usr/bin/sudo chmod 777 $eth");
exec("/usr/bin/sudo >$eth");
exec("/usr/bin/sudo echo DEVICE=$dev'\n'ONBOOT=yes'\n'BOOTPROTO=static'\n'IPADDR=$ip'\n'NETMASK=$netmask'\n'GATEWAY=$gateway'\n'DNS1=223.6.6.6'\n'DNS2=114.114.114.114 >$eth");
exec("/usr/bin/sudo /etc/init.d/network restart");
exec("/usr/bin/sudo /etc/init.d/NetworkManager restart");
sleep(10);
include 'get_ipinfo.php';
include 'check_ip.php';
}
}
else {
echo "<script>alert('输入的IP信息不合法或者IP信息不完整，请检查确认后重新输入');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>
