<?php
exec("/usr/bin/sudo  scp /var/www/html/check_user_pwd.php /tmp");
exec("/usr/bin/sudo  scp /var/www/html/session_check.php /tmp");
?>
