<?php
$u_ip0=exec("/usr/bin/sudo ifconfig eth0|awk -F ':' 'NR==2{print $2 }'|awk '{print $1}'");
$u_ip=exec("/usr/bin/sudo ifconfig eth1|awk -F ':' 'NR==2{print $2 }'|awk '{print $1}'");
$u_mac0=exec("/usr/bin/sudo ifconfig eth0|awk -F 'HWaddr ' 'NR==1{print $2 }' ");
$u_mac=exec("/usr/bin/sudo ifconfig eth1|awk -F 'HWaddr ' 'NR==1{print $2 }' ");
$u_netmask0=exec("/usr/bin/sudo ifconfig eth0 |awk -F 'Mask:' 'NR==2{print $2 }'");
$u_netmask=exec("/usr/bin/sudo ifconfig eth1 |awk -F 'Mask:' 'NR==2{print $2 }'");
$u_gateway=exec("/usr/bin/sudo ip route show| grep via|awk -F ' ' 'NR==1 {print $3}'");
$u_dns1=exec("/usr/bin/sudo cat /etc/resolv.conf |grep 'nameserver'|awk 'NR==1 {print $2}'");
$u_dns2=exec("/usr/bin/sudo cat /etc/resolv.conf |grep 'nameserver'|awk 'NR==2 {print $2}'");
$u_uuid=exec("/usr/bin/sudo cat /opt/www/ettschoolmitm/mitm2ettschool/uuid");
?>
