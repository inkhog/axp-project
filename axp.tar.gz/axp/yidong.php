<form action="yd_dns.php" method="post">
<center>移动、教育网DNS1: <input type="text" name="dns1" ></center><br/>
<center>移动、教育网DNS2: <input type="text" name="dns2" ></center><br/>
<center><input type="submit"  value="提交" /></center>
</form>
<center>点击提交按钮之后请等候1分钟，请勿重复提交，系统配置DNS需要一定时间，请耐心等待...</center><br/>
<?php
include 'session_check.php';
?>

