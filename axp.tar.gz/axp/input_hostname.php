<form action="hostname.php" method="post">
<center> 请输入服务器主机名（学校名+班级名的全拼，禁止使用中文名！）: <input type="text" name="hostname" ></center><br/>
<center><input type="submit"  value="提交" /></center>
</form>
<?php
include 'session_check.php';
?>

