<?php 
include 'session_check.php';
$is_exit = exec("/usr/bin/sudo sed -n '1,\$p' /etc/squid/allow_macs |wc -l");
if ($is_exit=="0")
{
echo "<script>alert('目前无用户添加的MAC地址！没有可删除的MAC地址！！！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else
{
exec("/usr/bin/sudo sed -i '1,\$d' /etc/squid/allow_macs");
echo "<script>alert('删除已添加mac地址成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>


