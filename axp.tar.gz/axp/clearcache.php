<?php
exec("/usr/bin/sudo rm -rf /opt/cache_hls/*");
exec("/usr/bin/sudo rm -rf /opt/cache_mp4/*");
exec("/usr/bin/sudo rm -rf /opt/cache_ettsch/*");
exec("/usr/bin/sudo rm -rf /opt/cache_aixuepad/*");
exec("/usr/bin/sudo rm -rf /data/cache/*");
exec("/usr/bin/sudo > /var/log/squid/access.log");
exec("/usr/bin/sudo > /var/log/squid/cache.log");
exec("/usr/bin/sudo > /var/log/squid/squid.out");
exec("/usr/bin/sudo > /var/log/squid/store.log");
exec("/usr/bin/sudo rm -rf /var/log/squid/*.gz");
echo "<script>alert('清除缓存成功！');location.href='statu.php';</script>";
?>
