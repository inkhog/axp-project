<?php
include 'session_check.php';
$if_up = exec("iptables -nvL|grep '123.103'|wc -l");
exec("/usr/bin/sudo /bin/sh /var/www/html/tools/down_firewall.sh");
if($if_u ==0){
echo "<script>alert('您已【关闭】行为管理！');location.href='statu.php';</script>";
}
else{
echo "<script>alert('【关闭】行为管理-失败！！！！');location.href='statu.php';</script>";
}
?>


