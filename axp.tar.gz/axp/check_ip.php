<?php
include 'session_check.php';
if (filter_var($u_ip, FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)){
echo "配置IP成功！<br/>";
echo "IP信息如下:<br/>";
echo "网卡：eth1<br/>";
echo "IP：$u_ip<br/>";
echo "子网：$u_netmask<br/>";
echo "网关：$u_gateway<br/>";
echo "DNS1：$u_dns1<br/>";
echo "DNS2：$u_dns2<br/><br/>";
echo "检测是否能ping通外网:<br/>";
$schoolett = "school.etiantian.com";
exec("ping -n -c 6 $schoolett", $ping1, $status);
echo "<pre>".htmlentities(print_r($ping1, true))."</pre>";
}else{
echo "配置IP信息失败，请重试！";
}
?>
