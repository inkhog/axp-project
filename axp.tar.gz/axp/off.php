<?php
include 'session_check.php';
exec("/usr/bin/sudo shutdown -h now");
echo "<script>alert('【关闭】服务器成功！');location.href='statu.php';</script>";
?>

