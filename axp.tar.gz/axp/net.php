</br></br></br>
<meta charset="UTF-8">
<center>
爱学派服务器配置选择
</br></br></br>
<form action="dg.php" method="post" name="dg" >
<input type="submit" value="1.东莞本地爱学派" /></br>
</form>

<form action="bj.php" method="post" name="bj" >
<input type="submit" value="2.非东莞本地爱学派">
</form>

