<form action="static_ip.php" method="post">
<center>请根据学校内网环境，配置[eth1]网卡的IP，子网掩码，网关，DNS不需要输入!</center><br/>
<center>IP: <input type="text" name="ip" ></center><br/>
<center>子网掩码: <input type="text" name="netmask" ></center><br/>
<center>网关: <input type="text" name="gateway" ></center><br/>
<center><input type="submit"  value="提交" /></center>
</form>
<center>点击提交按钮之后请等候1分钟，请勿重复提交，系统配置ip需要一定时间，请耐心等待...</center><br/>
<?php
include 'session_check.php';
date_default_timezone_set("Asia/Shanghai");
echo "<center>现在时间: ".date('Y-m-d,H:i:s</center>');
?>

