<?php 
include 'session_check.php';
$hostname=$_POST["hostname"];
if (ereg("[a-zA-Z0-9]",$hostname)){
$date=date('Ymd');
exec("/usr/bin/sudo hostname $hostname-$date ");
exec("/usr/bin/sudo bash ");
exec("/usr/bin/sudo sed -i 's/^HOSTNAME=.*/HOSTNAME=$hostname-$date/g' /etc/sysconfig/network ");
echo "<script>alert('修改主机名成功！主机名为：$hostname-$date');location.href='statu.php';</script>";
}
else
{
echo "<script>alert('主机名不能为【空】或主机名不能为【中文】！请重新输入！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>

