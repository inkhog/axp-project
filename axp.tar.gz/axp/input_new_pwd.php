<form action="edit_pwd.php" method="post">
<center>请输入旧的密码 ：<input type="password" name="pwd0" /></center></br>
<center>请输入新的密码 ：<input type="password" name="pwd1" /></center></br>
<center>请再次输入密码 ：<input type="password" name="pwd2" /></center></br>
<center><input type="submit" value="提交" /></center>
</form>
<?php 
include 'session_check.php';
?>


