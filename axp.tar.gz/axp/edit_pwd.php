<?php
$pwd_file = '/var/www/html/check_user_pwd.php';
$session_file = '/var/www/html/session_check.php';
$pwd0 = md5($_POST["pwd0"]);
$pwd1 = md5($_POST["pwd1"]);
$pwd2 = md5($_POST["pwd2"]);
$old_pwd = exec("/usr/bin/sudo cat check_user_pwd.php |grep '$password=\"'|awk -F '\"' '{print $2}' ");
if ($pwd0 !="" && $pwd0 == $old_pwd){
if ($pwd1 == $pwd2) {
exec("/usr/bin/sudo  sed -i '4s/$pwd=.*/$pwd=\"$pwd1\";/g' $pwd_file");
exec("/usr/bin/sudo  sed -i '4s/$pwd=.*/$pwd=\"$pwd1\";/g' $session_file");
include 'cp_pwd.php';
echo "<script>alert('修改密码成功!');location.href='statu.php';</script>";
}
else
{
echo "<script>alert('两次输入密码不一致，请重新输入');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
}
else
{
echo "<script>alert('旧密码输入错误，请重新输入');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>
