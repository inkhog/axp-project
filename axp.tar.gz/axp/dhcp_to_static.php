<?php
include 'session_check.php';
include 'get_ipinfo.php';

$dev = "eth1";
$eth = "/etc/sysconfig/network-scripts/ifcfg-eth1";
exec("/usr/bin/sudo chmod 777 $eth");
exec("/usr/bin/sudo echo DEVICE=$dev'\n'ONBOOT=yes'\n'BOOTPROTO=static'\n'IPADDR=$u_ip'\n'NETMASK=$u_netmask'\n'GATEWAY=$u_gateway'\n'DNS1=223.6.6.6'\n'DNS2=114.114.114.114 >$eth");
exec("/usr/bin/sudo /etc/init.d/network restart");
exec("/usr/bin/sudo /etc/init.d/NetworkManager restart");
exec("/usr/bin/sudo source /etc/profile");

sleep(10);
include 'get_ipinfo.php';
include 'check_ip.php';
?>
