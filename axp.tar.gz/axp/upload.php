<center>
<?php
include 'session_check.php';
echo "文件上传：";
?>
<br/><br/>
<html>
<body>
<form action="upload_file.php" method="post"
enctype="multipart/form-data">
<label for="file">请选择要上传的文件:</label>
<input type="file" name="file" id="file" /> 
<br/><br/>
<input type="submit" name="upload_f" value="提交" />
</form>

<form action="http://10.20.30.254:888/ett" method="post" >
<center><input type="submit" value="查看已上传文件"></center>
</form>

<form action="del_upload_file.php" method="post">
<input type="submit"  value="删除已上传所有文件" /></center><br/>
</form>
</body>
</html>



