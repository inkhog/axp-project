<?php
include 'session_check.php';
$add_urls = $_POST["add_urls"];
$urls_file = "/etc/squid/allow_add_urls";
if(ereg("^\.+[^A-Z]+\.+[a-zA-Z]",$add_urls)){
exec("/usr/bin/sudo  echo '$add_urls' >> $urls_file");
exec("/usr/bin/sudo squid -krec");
echo "<script>alert('添加白名单成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else
{
echo "<script>alert('输入的URL地址不合法，请重新输入！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>

