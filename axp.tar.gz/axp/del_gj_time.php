<?php 
include 'session_check.php';
$is_exit = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown -h now'|wc -l");
$u_h = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown'|awk -F ' ' '{print $2}'");
$u_m = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown'|awk -F ' ' '{print $1}'");
if ($is_exit=="0")
{
echo "<script>alert('目前无设置的自动关机时间，无需删除！！！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else
{
exec("/usr/bin/sudo  chmod 777  /etc/crontab");
exec("/usr/bin/sudo sed  -i '/shutdown/d' /etc/crontab");
exec("/usr/bin/sudo  chmod 0600  /etc/crontab");
exec("/usr/bin/sudo  /etc/init.d/crond restart");
echo "<script>alert('删除已设置自动关机时间成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>

