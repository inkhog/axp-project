<?php 
include 'session_check.php';
$is_exit = exec("/usr/bin/sudo sed -n '2,\$p' /etc/squid/allow_ips |wc -l");
if ($is_exit=="0")
{
echo "<script>alert('目前无用户添加的信任IP！没有可删除的IP！！！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
else
{
exec("/usr/bin/sudo sed -i '2,\$d' /etc/squid/allow_ips");
echo "<script>alert('删除已添加ip成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>


