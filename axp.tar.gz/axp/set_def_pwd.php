<?php
$pwd_file = '/var/www/html/check_user_pwd.php';
$session_file = '/var/www/html/session_check.php';
$sn = 'f3c0e024c5bf0230087e3998b01255ca';
$user_sn =  md5($_POST["user_sn"]);
if ($user_sn == $sn){
exec("/usr/bin/sudo  sed -i '4s/$password=.*/$password=\"74ba0da6ac7cba8697146451a634dfb8\";/g' $pwd_file ");
exec("/usr/bin/sudo  sed -i '4s/$password=.*/$password=\"74ba0da6ac7cba8697146451a634dfb8\";/g' $session_file ");
include 'cp_pwd.php';
echo "<script>alert('重置密码成功！密码为:ett@admin@root');location.href='login.php';</script>";
}
else
{
echo "<script>alert('验证码不正确，请重新输入');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
}
?>
