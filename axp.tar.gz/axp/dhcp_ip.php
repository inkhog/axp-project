<?php
include 'session_check.php';
$eth = "/etc/sysconfig/network-scripts/ifcfg-eth1";
$dev = "eth1";
exec("/usr/bin/sudo chmod 777 $eth");
exec("/usr/bin/sudo >$eth");
exec("/usr/bin/sudo echo DEVICE=$dev'\n'ONBOOT=yes'\n'BOOTPROTO=dhcp'\n'DNS1=223.6.6.6'\n'DNS2=114.114.114.114 >$eth");
exec("/usr/bin/sudo /etc/init.d/network restart");
exec("/usr/bin/sudo /etc/init.d/NetworkManager restart");
sleep(10);
include 'get_ipinfo.php';
include 'check_ip.php';
?>

