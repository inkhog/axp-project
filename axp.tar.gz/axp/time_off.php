<center>定时【开机时间】设置:<br/>
服务器接显示器和键盘，开机按del键进入bios，然后如下图1，2，3操作：<br/>
<img src='dskj.png' width="800" height="700">'</center><br/>
<center>定时【关机时间】设置：</center>
<form action="conf_off.php" method="post">
<center><font color='red'>仅允许设置当天下午16:00到第二天上午06:55之间，建议设置在【学校统一断电】之前【半小时】！</font></center><br/>
<center>请选择关机时间---<select name='gj_h'>
<option value='16'> 16</option>
<option value='17'> 17</option>
<option value='18'> 18</option>
<option value='19'> 19</option>
<option value='20'> 20</option>
<option value='21'> 21</option>
<option value='22' selected>22</option>
<option value='23'> 23</option>
<option value='00'> 00</option>
<option value='01'> 01</option>
<option value='02'> 02</option>
<option value='03'> 03</option>
<option value='04'> 04</option>
<option value='05'> 05</option>
<option value='06'> 06</option>
</select>
:
<select name='gj_m'>
<option value='00'> 00</option>
<option value='05'> 05</option>
<option value='10'> 10</option>
<option value='15'> 15</option>
<option value='20'> 20</option>
<option value='25'> 25</option>
<option value='30' selected>30</option>
<option value='35'> 35</option>
<option value='40'> 40</option>
<option value='45'> 45</option>
<option value='50'> 50</option>
<option value='55'> 55</option>
</select>
</center>
<br/>
<center><input type="submit"  value="提交" /></center>
</form>
<form action="del_off_time.php" method="post">
<center><input type="submit" value="删除已设置关机时间" /></center>
</form>

<?php
include 'session_check.php';
$is_exit = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown -h now'|wc -l");
$u_h = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown'|awk -F ' ' '{print $2}'");
$u_m = exec("/usr/bin/sudo cat /etc/crontab |grep 'shutdown'|awk -F ' ' '{print $1}'");
if ($is_exit==0)
{
echo "<center><font color='blue'>【目前无设置的自动关机时间!】</font></center>";
}
else
{
echo "<center>已设置的自动关机时间为 -【<font color='blue'>$u_h:$u_m</font>】</center>";
}
?>
